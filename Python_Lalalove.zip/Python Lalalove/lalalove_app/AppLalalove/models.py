from django.db import models

# Create your models here.

class Usuario(models.Model):
    nombre = models.CharField(max_length=40)
    apellido = models.CharField(max_length=40)
    email = models.EmailField()


class Modelo(models.Model):
    marca = models.CharField(max_length=40)
    modelo = models.CharField(max_length=40)
    precio = models.IntegerField()


class Tendencia(models.Model):
    marca = models.CharField(max_length=40)
    descripcion = models.CharField(max_length=40)
    precio = models.IntegerField()  